package org.example;

import java.util.ArrayList;
import java.util.Scanner;

public class MainApp {
    private static ArrayList<Passageiro> passageiros = new ArrayList<>();
    private static int contadorId = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n1 - Cadastrar passageiro\n2 - Listar passageiros\n3 - Sair");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    try {
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();
                        System.out.print("CPF: ");
                        String cpf = scanner.nextLine();
                        System.out.print("Email: ");
                        String email = scanner.nextLine();

                        Passageiro p = new Passageiro(contadorId++, nome, cpf, email);
                        passageiros.add(p);
                        System.out.println("Passageiro cadastrado com sucesso!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Erro: " + e.getMessage());
                    }
                    break;
                case 2:
                    passageiros.forEach(System.out::println);
                    break;
                case 3:
                    System.out.println("Encerrando o programa.");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 3);

        scanner.close();
    }
}
