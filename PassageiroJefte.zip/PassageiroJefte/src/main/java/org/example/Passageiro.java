package org.example;

import java.util.regex.Pattern;

public class Passageiro {
    private int id;
    private String nome;
    private String cpf;
    private String email;

    public Passageiro(int id, String nome, String cpf, String email) {
        if (!isCpfValido(cpf)) throw new IllegalArgumentException("CPF inválido");
        if (!isEmailValido(email)) throw new IllegalArgumentException("Email inválido");

        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
    }

    // Validação simplificada de CPF para fins educacionais
    public static boolean isCpfValido(String cpf) {
        cpf = cpf.replaceAll("\\D", "");

        if (cpf.length() != 11) return false;
        if (cpf.equals("00000000000") || cpf.equals("11111111111") || cpf.equals("12345678900")) return false;

        return true; // Supõe válido se passar as regras básicas
    }

    public static boolean isEmailValido(String email) {
        return Pattern.matches("^[\\w\\.-]+@[\\w\\.-]+\\.[a-z]{2,}$", email.toLowerCase());
    }

    @Override
    public String toString() {
        return String.format("ID: %d, Nome: %s, CPF: %s, Email: %s", id, nome, cpf, email);
    }
}
