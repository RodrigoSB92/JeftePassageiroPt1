package com.snack;

import static org.junit.jupiter.api.Assertions.*;

import org.example.Passageiro;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class PassageiroTest {

    @Test
    void testCpfValido() {
        Assertions.assertTrue(Passageiro.isCpfValido("529.982.247-25"));
    }

    @Test
    void testCpfInvalido() {
        assertFalse(Passageiro.isCpfValido("123.456.789-00"));
    }

    @Test
    void testEmailValido() {
        assertTrue(Passageiro.isEmailValido("teste@dominio.com"));
    }

    @Test
    void testEmailInvalido() {
        assertFalse(Passageiro.isEmailValido("teste@dominio"));
    }

    @Test
    void testCadastroPassageiro() {
        Passageiro p = new Passageiro(1, "João", "529.982.247-25", "joao@email.com");
        assertEquals("João", p.toString().contains("João") ? "João" : "");
    }
}
